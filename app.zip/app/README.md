# MiniPotato Bot


note にて解説しているので、そちらをご参照ください！

解説ページはこちら　[https://note.com/exteoi/n/n0ea64e258797](https://note.com/exteoi/n/n0ea64e258797)